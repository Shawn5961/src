#include "set.h"

//Getter for the size property of the set
int Set :: getSize()
{
	return size;
}
